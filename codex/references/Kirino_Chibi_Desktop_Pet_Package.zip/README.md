# 桐乃 Q 版桌宠源码包

已按参考图修正为：浅蓝白水手服、紫红领结、灰蓝百褶裙、深色过膝袜、金棕色侧马尾、紫色发夹，以及露出脚背的黑色半包式玛丽珍鞋。

## 运行

```powershell
npm install
npm start
```

窗口透明、无边框、置顶，人物可拖动。右键可以退出。数字键切换动作：

- `1` 可爱待机
- `2` 害羞
- `3` 思考
- `4` 任务完成
- `5` 任务失败

## 资产接口

- 基准图：`assets/kirino_base.png`
- 动作概念合图：`assets/action_sheet.png`
- 独立状态帧：`sprites/<state>/frame_001.png`
- 状态清单：`asset-manifest.json`

现在每个状态先放入 1 张概念帧，方便先完成桌宠逻辑和移植。后续可在同一目录下继续加入 `frame_002.png`、`frame_003.png`，再把 `renderer.js` 改成按 fps 循环播放。

## 参考实现

- Desktop-Pets（PyQt5，透明置顶窗口、逐帧 PNG、MIT 代码）：https://github.com/LGaben/Desktop-Pets
- DeskCat（Electron，Windows/macOS，精灵图配置在 `src/renderer/sprite-config.js`）：https://github.com/coglabss/deskcat
- 角色资料参考：官方动画角色页 https://www.oreimo-anime.com/1st/chara/index.html

代码壳是可移植的最小实现；角色图是基于你提供参考图生成的个人同人素材。

## 交互事件接口

```js
window.kirinoPet.taskCompleted(); // 任务完成动作，约 2.6 秒后回到待机
window.kirinoPet.taskFailed();    // 任务失败动作，约 2.6 秒后回到待机
window.kirinoPet.startThinking(); // 进入思考
window.kirinoPet.stopThinking();  // 回到待机
```

也可以发送消息：

```js
window.postMessage({ type: 'task-complete' });
window.postMessage({ type: 'task-failed' });
window.postMessage({ type: 'thinking' });
```

鼠标移动到人物图像或点击人物时，会自动触发害羞动作。后续如果接入全局鼠标监听，可把命中坐标映射到人物窗口，再调用同一个 `setState('shy')`。

## 傲娇性格层

已加入 `tsun` 状态：双臂抱胸、侧目、脸红、嘴硬。数字键 `6` 可测试。完成和失败动作也会保留这种“嘴上嫌弃、实际在意”的表情方向。

## Windows 10+ 外部触发接口

程序启动后监听 `http://127.0.0.1:19751`：

```powershell
Invoke-RestMethod http://127.0.0.1:19751/api/action/complete
Invoke-RestMethod http://127.0.0.1:19751/api/action/failed
Invoke-RestMethod http://127.0.0.1:19751/api/action/shy
Invoke-RestMethod http://127.0.0.1:19751/api/action/thinking
Invoke-RestMethod http://127.0.0.1:19751/api/action/tsun
Invoke-RestMethod http://127.0.0.1:19751/api/action/idle
```

第一个动作是常驻 idle；其余动作播放约 2.6 秒后自动回到 idle。接口只监听本机回环地址，适用于 Windows 10/11。

## 帧率策略

- 交互状态（害羞、思考、完成、失败）：60 FPS。
- 普通 idle：30 FPS。
- idle 持续 60 秒无人操作：12 FPS 深度静置。
- 鼠标靠近、拖动或 HTTP 触发动作时自动恢复高帧率。
