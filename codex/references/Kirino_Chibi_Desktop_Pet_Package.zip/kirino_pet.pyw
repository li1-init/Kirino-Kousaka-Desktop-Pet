import tkinter as tk, threading, json
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from PIL import Image, ImageTk
ROOT=Path(__file__).parent; SPR=ROOT/'sprites'; states=['idle','shy','thinking','success','failed','wave']; frames={s:[Image.open(f).convert('RGBA') for f in sorted((SPR/s).glob('frame_*.png'))] for s in states}; state='idle'; idx=0; timer=None; deep_timer=None; dormant=False
class API(BaseHTTPRequestHandler):
 def do_GET(self):
  m={'/api/action/wave':'wave','/api/action/idle':'idle','/api/action/shy':'shy','/api/action/thinking':'thinking','/api/action/complete':'success','/api/action/success':'success','/api/action/failed':'failed'}
  if self.path in m: root.after(0,lambda:set_state(m[self.path],0 if m[self.path]=='idle' else 2600)); self.send_response(200); self.end_headers(); self.wfile.write(json.dumps({'ok':True,'action':m[self.path]}).encode())
  else: self.send_response(404); self.end_headers()
 def log_message(self,*args): pass
def fps():
 if state in ('success','failed','shy','thinking'): return 60
 if dormant: return 12
 return 30
def set_state(s,duration=0):
 global state,idx,timer,dormant,deep_timer
 state=s; idx=0; dormant=False
 if deep_timer: root.after_cancel(deep_timer)
 deep_timer=root.after(60000,go_dormant)
 if timer: root.after_cancel(timer)
 if duration: timer=root.after(duration,lambda:set_state('idle'))

def go_dormant():
 global dormant
 if state=='idle': dormant=True

def update():
 global idx
 im=ImageTk.PhotoImage(frames[state][idx]); label.configure(image=im); label.image=im; idx=(idx+1)%len(frames[state]); root.after(int(1000/fps()),update)
def drag(e): set_state('shy',1800); root.geometry(f'+{e.x_root-128}+{e.y_root-128}')
root=tk.Tk(); root.overrideredirect(True); root.attributes('-topmost',True); root.configure(bg='magenta'); root.wm_attributes('-transparentcolor','magenta'); label=tk.Label(root,bg='magenta',bd=0); label.pack(); label.bind('<B1-Motion>',drag); label.bind('<Enter>',lambda e:set_state('shy',1800)); label.bind('<Button-1>',lambda e:set_state('shy',2200)); menu=tk.Menu(root,tearoff=0); menu.add_command(label='回到待机',command=lambda:set_state('idle')); menu.add_separator(); menu.add_command(label='退出桐乃桌宠',command=root.destroy); root.bind('<Button-3>',lambda e:menu.tk_popup(e.x_root,e.y_root)); root.bind('<Escape>',lambda e:root.destroy()); root.focus_force(); root.geometry('256x256+100+100'); set_state('idle'); update(); threading.Thread(target=lambda:HTTPServer(('127.0.0.1',19751),API).serve_forever(),daemon=True).start(); root.mainloop()


