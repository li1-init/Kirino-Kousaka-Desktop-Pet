const { app, BrowserWindow, Menu } = require('electron');
const { createServer } = require('http');
const path = require('path');
let win;
function createWindow() {
  win = new BrowserWindow({width:300,height:390,useContentSize:true,frame:false,transparent:true,alwaysOnTop:true,resizable:false,skipTaskbar:true,hasShadow:false,webPreferences:{contextIsolation:false,nodeIntegration:true,sandbox:false}});
  win.setAlwaysOnTop(true,'floating'); win.loadFile(path.join(__dirname,'src','index.html'));
  win.webContents.on('context-menu',()=>Menu.buildFromTemplate([{label:'退出桌宠',click:()=>app.quit()}]).popup({window:win}));
}
function startApi(){
 createServer((req,res)=>{ const u=new URL(req.url,'http://127.0.0.1'); const map={'/api/action/idle':'idle','/api/action/shy':'shy','/api/action/thinking':'thinking','/api/action/complete':'success','/api/action/success':'success','/api/action/failed':'failed','/api/action/tsun':'tsun'}; const action=map[u.pathname]; res.setHeader('Access-Control-Allow-Origin','*'); res.setHeader('Content-Type','application/json'); if(action&&win){win.webContents.send('pet-action',action);res.end(JSON.stringify({ok:true,action}));} else {res.statusCode=404;res.end(JSON.stringify({ok:false,error:'unknown action'}));}}).listen(19751,'127.0.0.1');
}
app.whenReady().then(()=>{createWindow();startApi();}); app.on('window-all-closed',e=>e.preventDefault());

