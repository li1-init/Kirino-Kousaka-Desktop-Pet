const { ipcRenderer } = require('electron');
const image=document.getElementById('kirino'); const states=['idle','shy','thinking','success','failed','tsun']; const frames=Object.fromEntries(states.map(s=>[s,Array.from({length:6},(_,i)=>`../sprites/${s}/frame_${String(i+1).padStart(3,'0')}.png`)])); let state='idle',frame=0,timer;
function setState(next,duration=0){if(!frames[next])return;state=next;frame=0;image.src=frames[state][0];document.body.dataset.state=state;clearTimeout(timer);if(duration)timer=setTimeout(()=>setState('idle'),duration);}
setInterval(()=>{frame=(frame+1)%6;image.src=frames[state][frame]},140);
ipcRenderer.on('pet-action',(_,a)=>setState(a,a==='idle'?0:2600));
window.kirinoPet={setState,taskCompleted:()=>setState('success',2600),taskFailed:()=>setState('failed',2600),startThinking:()=>setState('thinking'),stopThinking:()=>setState('idle'),tsundere:()=>setState('tsun',2200)};
image.addEventListener('mouseenter',()=>setState('shy',1800)); image.addEventListener('click',()=>setState('shy',2200)); window.addEventListener('keydown',e=>{const m={'1':'idle','2':'shy','3':'thinking','4':'success','5':'failed','6':'tsun'};if(m[e.key])setState(m[e.key]);}); setState('idle');
