@echo off
pyw "%~dp0kirino_pet.pyw"
