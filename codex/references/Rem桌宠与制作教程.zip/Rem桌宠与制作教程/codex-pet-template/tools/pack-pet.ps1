[CmdletBinding()]
param(
  [string]$PetDir = (Split-Path -Parent $PSScriptRoot),
  [string]$OutputPath = ""
)

$ErrorActionPreference = "Stop"
& (Join-Path $PSScriptRoot "validate-pet.ps1") -PetDir $PetDir

$manifestPath = Join-Path $PetDir "pet.json"
$manifest = Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json
$spriteName = if ([string]::IsNullOrWhiteSpace([string]$manifest.spritesheetPath)) { "spritesheet.webp" } else { [string]$manifest.spritesheetPath }
$spritePath = Join-Path $PetDir $spriteName

if ([string]::IsNullOrWhiteSpace($OutputPath)) {
  $OutputPath = Join-Path $PetDir "$($manifest.id).zip"
}
$OutputPath = [IO.Path]::GetFullPath($OutputPath)
if (Test-Path -LiteralPath $OutputPath) {
  throw "目标文件已经存在：$OutputPath"
}

Compress-Archive -LiteralPath @($manifestPath, $spritePath) -DestinationPath $OutputPath -CompressionLevel Optimal
Write-Host "已生成：$OutputPath" -ForegroundColor Green
