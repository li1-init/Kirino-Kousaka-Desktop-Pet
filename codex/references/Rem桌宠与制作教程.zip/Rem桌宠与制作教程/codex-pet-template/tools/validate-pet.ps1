[CmdletBinding()]
param(
  [string]$PetDir = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = "Stop"

function Fail([string]$Message) {
  throw "校验失败：$Message"
}

function Get-WebPDimensions([byte[]]$Bytes) {
  if ($Bytes.Length -lt 30) {
    Fail "精灵图太小，无法识别为 WebP。"
  }

  $riff = [Text.Encoding]::ASCII.GetString($Bytes, 0, 4)
  $webp = [Text.Encoding]::ASCII.GetString($Bytes, 8, 4)
  if ($riff -ne "RIFF" -or $webp -ne "WEBP") {
    Fail "spritesheet.webp 不是有效的 WebP 文件。"
  }

  $offset = 12
  while ($offset + 8 -le $Bytes.Length) {
    $fourCC = [Text.Encoding]::ASCII.GetString($Bytes, $offset, 4)
    $chunkSize = [BitConverter]::ToUInt32($Bytes, $offset + 4)
    $data = $offset + 8
    if ($data + $chunkSize -gt $Bytes.Length) {
      Fail "WebP 数据块长度异常。"
    }

    if ($fourCC -eq "VP8X") {
      if ($chunkSize -lt 10) { Fail "VP8X 数据块过短。" }
      $width = 1 + [int]$Bytes[$data + 4] + ([int]$Bytes[$data + 5] -shl 8) + ([int]$Bytes[$data + 6] -shl 16)
      $height = 1 + [int]$Bytes[$data + 7] + ([int]$Bytes[$data + 8] -shl 8) + ([int]$Bytes[$data + 9] -shl 16)
      return [pscustomobject]@{ Width = $width; Height = $height }
    }

    if ($fourCC -eq "VP8L") {
      if ($chunkSize -lt 5 -or $Bytes[$data] -ne 0x2F) { Fail "VP8L 数据块无效。" }
      $bits = [BitConverter]::ToUInt32($Bytes, $data + 1)
      $width = 1 + ($bits -band 0x3FFF)
      $height = 1 + (($bits -shr 14) -band 0x3FFF)
      return [pscustomobject]@{ Width = $width; Height = $height }
    }

    if ($fourCC -eq "VP8 ") {
      if ($chunkSize -lt 10) { Fail "VP8 数据块过短。" }
      if ($Bytes[$data + 3] -ne 0x9D -or $Bytes[$data + 4] -ne 0x01 -or $Bytes[$data + 5] -ne 0x2A) {
        Fail "VP8 起始码无效。"
      }
      $width = [BitConverter]::ToUInt16($Bytes, $data + 6) -band 0x3FFF
      $height = [BitConverter]::ToUInt16($Bytes, $data + 8) -band 0x3FFF
      return [pscustomobject]@{ Width = $width; Height = $height }
    }

    $offset = $data + $chunkSize
    if ($chunkSize % 2 -eq 1) { $offset += 1 }
  }

  Fail "没有找到可识别的 WebP 图像数据块。"
}

function Get-FrameSpec($Manifest) {
  if ($null -ne $Manifest.frame) {
    return [pscustomobject]@{
      Width = [int]$Manifest.frame.width
      Height = [int]$Manifest.frame.height
      Columns = [int]$Manifest.frame.columns
      Rows = [int]$Manifest.frame.rows
    }
  }

  $rows = if ([int]$Manifest.spriteVersionNumber -ge 2) { 11 } else { 9 }
  return [pscustomobject]@{ Width = 192; Height = 208; Columns = 8; Rows = $rows }
}

$manifestPath = Join-Path $PetDir "pet.json"
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
  Fail "找不到 $manifestPath"
}

try {
  $manifest = Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json
} catch {
  Fail "pet.json 不是有效 JSON：$($_.Exception.Message)"
}

if ([string]::IsNullOrWhiteSpace([string]$manifest.displayName)) {
  Fail "pet.json 必须包含 displayName。"
}
if ([string]::IsNullOrWhiteSpace([string]$manifest.id)) {
  Fail "pet.json 必须包含 id。"
}
if ([string]$manifest.id -notmatch "^[a-z0-9-]+$") {
  Fail "id 只能使用小写字母、数字和连字符。"
}

$relativeSprite = [string]$manifest.spritesheetPath
if ([string]::IsNullOrWhiteSpace($relativeSprite)) {
  $relativeSprite = "spritesheet.webp"
}
if ([IO.Path]::IsPathRooted($relativeSprite) -or $relativeSprite -match "(^|[\\/])\.\.([\\/]|$)") {
  Fail "spritesheetPath 必须是宠物目录内的相对路径。"
}

$spritePath = Join-Path $PetDir $relativeSprite
if (-not (Test-Path -LiteralPath $spritePath -PathType Leaf)) {
  Fail "找不到 $spritePath"
}

$bytes = [IO.File]::ReadAllBytes($spritePath)
$dimensions = Get-WebPDimensions $bytes
$frame = Get-FrameSpec $manifest

if ($frame.Width -le 0 -or $frame.Height -le 0 -or $frame.Columns -le 0 -or $frame.Rows -le 0) {
  Fail "frame 的宽高、列数和行数必须大于 0。"
}

$expectedWidth = $frame.Width * $frame.Columns
$expectedHeight = $frame.Height * $frame.Rows
if ($dimensions.Width -ne $expectedWidth -or $dimensions.Height -ne $expectedHeight) {
  Fail "网格尺寸不匹配：图片为 $($dimensions.Width)×$($dimensions.Height)，网格需要 $expectedWidth×$expectedHeight。"
}

$version = [int]$manifest.spriteVersionNumber
if ($version -ge 2 -and ($expectedWidth -ne 1536 -or $expectedHeight -ne 2288)) {
  Fail "v2 图集必须是 1536×2288（8×11，单帧 192×208）。"
}
if ($version -lt 2 -and ($expectedWidth -ne 1536 -or $expectedHeight -ne 1872)) {
  Fail "旧版兼容图集必须是 1536×1872（8×9，单帧 192×208）。"
}

$frameCount = $frame.Columns * $frame.Rows
if ($frameCount -gt 256) {
  Fail "总帧数不能超过 256。"
}

if ($null -ne $manifest.animations) {
  $animationNames = @($manifest.animations.PSObject.Properties.Name)
  foreach ($property in $manifest.animations.PSObject.Properties) {
    $name = $property.Name
    $animation = $property.Value
    $frames = @($animation.frames)
    if ($frames.Count -eq 0) {
      Fail "动画 $name 至少需要一帧。"
    }
    foreach ($frameIndexValue in $frames) {
      $frameIndex = [int]$frameIndexValue
      if ($frameIndex -lt 0 -or $frameIndex -ge $frameCount) {
        Fail "动画 $name 引用了不存在的帧 $frameIndex。"
      }
    }
    if ($null -ne $animation.fps) {
      $fps = [double]$animation.fps
      if ($fps -le 0 -or $fps -gt 60 -or [double]::IsNaN($fps) -or [double]::IsInfinity($fps)) {
        Fail "动画 $name 的 fps 必须大于 0 且不超过 60。"
      }
    }
    $fallback = [string]$animation.fallback
    if (-not [string]::IsNullOrWhiteSpace($fallback) -and
        $fallback -ne "idle" -and
        $animationNames -notcontains $fallback) {
      Fail "动画 $name 的 fallback=$fallback 不存在。"
    }
  }
}

$hash = (Get-FileHash -LiteralPath $spritePath -Algorithm SHA256).Hash
Write-Host "通过：$($manifest.displayName) ($($manifest.id))" -ForegroundColor Green
Write-Host "精灵图：$($dimensions.Width) × $($dimensions.Height) px，$($frame.Columns) × $($frame.Rows) 格，共 $frameCount 帧"
Write-Host "单帧：$($frame.Width) × $($frame.Height) px"
Write-Host "SHA256：$hash"
